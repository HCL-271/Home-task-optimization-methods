-- ������� �����, �� ������� ����������� ����� �������� ������ �� ������ 'Michelin'. --
SELECT Step.name, 10*COUNT(A2.pilot_id) + 8*COUNT(B2.pilot_id) + 6*COUNT(C2.pilot_id) + 5*COUNT(D2.pilot_id) + 4*COUNT(E2.pilot_id) + 3*COUNT(F2.pilot_id) + 2*COUNT(G2.pilot_id) + COUNT(H2.pilot_id) AS '����� � Michelin',
                      10*COUNT(A1.pilot_id) + 8*COUNT(B1.pilot_id) + 6*COUNT(C1.pilot_id) + 5*COUNT(D1.pilot_id) + 4*COUNT(E1.pilot_id) + 3*COUNT(F1.pilot_id) + 2*COUNT(G1.pilot_id) + COUNT(H1.pilot_id) AS '���������'
FROM Step
	INNER JOIN Result ON Step.step_id = Result.step_id
	INNER JOIN Pilot ON Pilot.pilot_id = Result.pilot_id
	INNER JOIN Commandpilot ON Commandpilot.pilot_id = Pilot.pilot_id
	INNER JOIN Command ON Commandpilot.command_id = Command.command_id LEFT JOIN
	Result A1 ON A1.step_id = Result.step_id AND A1.pilot_id = Result.pilot_id AND A1.place = 1 AND Command.tire <> 'Michelin' LEFT JOIN
	Result B1 ON B1.step_id = Result.step_id AND B1.pilot_id = Result.pilot_id AND B1.place = 2 AND Command.tire <> 'Michelin' LEFT JOIN
	Result C1 ON C1.step_id = Result.step_id AND C1.pilot_id = Result.pilot_id AND C1.place = 3 AND Command.tire <> 'Michelin' LEFT JOIN
	Result D1 ON D1.step_id = Result.step_id AND D1.pilot_id = Result.pilot_id AND D1.place = 4 AND Command.tire <> 'Michelin' LEFT JOIN
	Result E1 ON E1.step_id = Result.step_id AND E1.pilot_id = Result.pilot_id AND E1.place = 5 AND Command.tire <> 'Michelin' LEFT JOIN
	Result F1 ON F1.step_id = Result.step_id AND F1.pilot_id = Result.pilot_id AND F1.place = 6 AND Command.tire <> 'Michelin' LEFT JOIN
	Result G1 ON G1.step_id = Result.step_id AND G1.pilot_id = Result.pilot_id AND G1.place = 7 AND Command.tire <> 'Michelin' LEFT JOIN
	Result H1 ON H1.step_id = Result.step_id AND H1.pilot_id = Result.pilot_id AND H1.place = 8 AND Command.tire <> 'Michelin' LEFT JOIN
	Result A2 ON A2.step_id = Result.step_id AND A2.pilot_id = Result.pilot_id AND A2.place = 1 AND Command.tire = 'Michelin' LEFT JOIN
	Result B2 ON B2.step_id = Result.step_id AND B2.pilot_id = Result.pilot_id AND B2.place = 2 AND Command.tire = 'Michelin' LEFT JOIN
	Result C2 ON C2.step_id = Result.step_id AND C2.pilot_id = Result.pilot_id AND C2.place = 3 AND Command.tire = 'Michelin' LEFT JOIN
	Result D2 ON D2.step_id = Result.step_id AND D2.pilot_id = Result.pilot_id AND D2.place = 4 AND Command.tire = 'Michelin' LEFT JOIN
	Result E2 ON E2.step_id = Result.step_id AND E2.pilot_id = Result.pilot_id AND E2.place = 5 AND Command.tire = 'Michelin' LEFT JOIN
	Result F2 ON F2.step_id = Result.step_id AND F2.pilot_id = Result.pilot_id AND F2.place = 6 AND Command.tire = 'Michelin' LEFT JOIN
	Result G2 ON G2.step_id = Result.step_id AND G2.pilot_id = Result.pilot_id AND G2.place = 7 AND Command.tire = 'Michelin' LEFT JOIN
	Result H2 ON H2.step_id = Result.step_id AND H2.pilot_id = Result.pilot_id AND H2.place = 8 AND Command.tire = 'Michelin' 
GROUP BY step.name
HAVING (10*COUNT(A2.pilot_id) + 8*COUNT(B2.pilot_id) + 6*COUNT(C2.pilot_id) + 5*COUNT(D2.pilot_id) + 4*COUNT(E2.pilot_id) + 3*COUNT(F2.pilot_id) + 2*COUNT(G2.pilot_id) + COUNT(H2.pilot_id))>
(10*COUNT(A1.pilot_id) + 8*COUNT(B1.pilot_id) + 6*COUNT(C1.pilot_id) + 5*COUNT(D1.pilot_id) + 4*COUNT(E1.pilot_id) + 3*COUNT(F1.pilot_id) + 2*COUNT(G1.pilot_id) + COUNT(H1.pilot_id))