/*SELECT Grand_Prix_Name.Grand_prix_name , 
	SUM(A.score)/81 AS 'Michelin',
  SUM(B.score)/81
FROM Grand_Prix
	INNER JOIN Grand_Prix_Name ON Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id
	INNER JOIN Pitstop ON Grand_Prix.Grand_prix_id = Pitstop.Grand_prix_id
	INNER JOIN Tire ON Tire.Tire_id = Pitstop.Tire_id 
	INNER JOIN Grand_Prix_Result ON Grand_Prix.Grand_prix_id = Grand_Prix_Result.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	LEFT JOIN Grand_Prix_Result A ON Tire.Tire_name = 'Michelin' AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	LEFT JOIN Grand_Prix_Result B ON Tire.Tire_name <> 'Michelin'AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
GROUP BY Grand_Prix_Name.Grand_prix_name 

HAVING SUM(A.score) <
  SUM(B.score) */

  SELECT *
FROM Grand_Prix
	INNER JOIN Grand_Prix_Name ON Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id
	INNER JOIN Pitstop ON Grand_Prix.Grand_prix_id = Pitstop.Grand_prix_id
	INNER JOIN Tire ON Tire.Tire_id = Pitstop.Tire_id 
	INNER JOIN Grand_Prix_Result  ON Grand_Prix.Grand_prix_id = Grand_Prix_Result.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	LEFT JOIN Grand_Prix_Result A ON Tire.Tire_name = 'Michelin' AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id 
	AND Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id AND Grand_Prix.Grand_prix_id = Pitstop.Grand_prix_id AND  Tire.Tire_id = Pitstop.Tire_id 
	
	
	LEFT JOIN Grand_Prix_Result B ON Tire.Tire_name <> 'Michelin'AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id

	SELECT Grand_Prix_Name.Grand_prix_name , 
	SUM(A.score) AS 'Michelin',
  SUM(B.score)
FROM Grand_Prix
	INNER JOIN Grand_Prix_Name ON Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id
	INNER JOIN Pitstop ON Grand_Prix.Grand_prix_id = Pitstop.Grand_prix_id
	INNER JOIN Tire ON Tire.Tire_id = Pitstop.Tire_id 
	INNER JOIN Grand_Prix_Result ON Grand_Prix.Grand_prix_id = Grand_Prix_Result.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	LEFT JOIN Grand_Prix_Result A ON Tire.Tire_name = 'Michelin' AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	LEFT JOIN Grand_Prix_Result B ON Tire.Tire_name <> 'Michelin'AND Grand_Prix_Result.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
GROUP BY Grand_Prix_Name.Grand_prix_name 

--HAVING SUM(A.score) < SUM(B.score) 