
WITH Sum_Mich (summ,  gpname)
AS
(
SELECT SUM(Grand_Prix_Result.score) S, Grand_prix_name.Grand_prix_name
		FROM Grand_Prix 
	INNER JOIN Grand_Prix_Name ON Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id
	INNER JOIN Grand_Prix_Result ON Grand_Prix.Grand_prix_id = Grand_Prix_Result.Grand_prix_id
	INNER JOIN Pitstop ON Pitstop.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	INNER JOIN Tire ON Pitstop.Tire_id = Tire.Tire_id
	Where Tire.Tire_name = 'Michelin'
	Group By Grand_prix_name.Grand_prix_name

)
,
Sum_not (summ, gpname)
AS
(
SELECT SUM(Grand_Prix_Result.score) S,  Grand_prix_name.Grand_prix_name
		FROM Grand_Prix 
	INNER JOIN Grand_Prix_Name ON Grand_Prix_Name.Grand_prix_name_id = Grand_Prix.Grand_prix_name_id
	INNER JOIN Grand_Prix_Result ON Grand_Prix.Grand_prix_id = Grand_Prix_Result.Grand_prix_id
	INNER JOIN Pitstop ON Pitstop.Grand_prix_id = Grand_Prix.Grand_prix_id AND Pitstop.Pilot_id = Grand_Prix_Result.Pilot_id
	INNER JOIN Tire ON Pitstop.Tire_id = Tire.Tire_id
	Where Tire.Tire_name <> 'Michelin'
	Group By Grand_prix_name.Grand_prix_name

)


Select Sum_Mich.gpname, Sum_Mich.summ, Sum_not.summ From Sum_Mich JOIN Sum_not ON Sum_Mich.gpname = Sum_not.gpname
Where Sum_Mich.summ < Sum_not.summ


--Select Sum_Mich.gpname, Sum_Mich.summ, Sum_not.summ From Sum_Mich INNER JOIN Sum_not ON Sum_Mich.gpname = Sum_not.gpname
--Where Sum_Mich.summ < Sum_not.summ

