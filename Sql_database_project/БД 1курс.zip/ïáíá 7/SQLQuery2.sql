USE ddblab0
GO

EXEC sp_dropuser 'test';
EXEC sp_droplogin 'test';

CREATE LOGIN test WITH PASSWORD = '1234', DEFAULT_DATABASE = ddblab0
CREATE USER test FOR LOGIN test
select SCHEMA_NAME()