/* USE master -- Use - �������� �������� ���� ������ �� ��������� ���� ������ ��� ������������ ������ ���� ������ � SQL Server.

GO --GO ����������� ��������� SQL Server �� ��������� ������ ���������� Transact-SQL.

IF NOT EXISTS ( SELECT name FROM sys.databases
		WHERE name = N'FORMULA_1_LAB' )
CREATE DATABASE FORMULA_1_LAB

--USE FORMULA_1_LAB
--GO
*/

--USE [ddblab0]
--GO 

-- Drop Tables

IF OBJECT_ID (N'Sponsor_Support', N'U') IS NOT NULL 
   DROP TABLE dbo.Sponsor_Support

   
IF OBJECT_ID (N'.Pilot_Contract', N'U') IS NOT NULL 
   DROP TABLE dbo.Pilot_Contract
   
IF OBJECT_ID (N'Pilot_Result', N'U') IS NOT NULL 
   DROP TABLE dbo.Pilot_Result
   
IF OBJECT_ID (N'Pilot_Accident', N'U') IS NOT NULL 
   DROP TABLE dbo.Pilot_Accident
   
IF OBJECT_ID (N'Command_Result', N'U') IS NOT NULL 
   DROP TABLE dbo.Command_Result

IF OBJECT_ID (N'Pitstop', N'U') IS NOT NULL 
   DROP TABLE dbo.Pitstop

IF OBJECT_ID (N'Grand_Prix_Result', N'U') IS NOT NULL 
   DROP TABLE dbo.Grand_Prix_Result
   
IF OBJECT_ID (N'Lap_Record', N'U') IS NOT NULL 
   DROP TABLE dbo.Lap_Record
   
IF OBJECT_ID (N'Track_Config', N'U') IS NOT NULL 
   DROP TABLE dbo.Track_Config
   
IF OBJECT_ID (N'Accident', N'U') IS NOT NULL 
   DROP TABLE dbo.Accident
   
IF OBJECT_ID (N'Grand_Prix', N'U') IS NOT NULL 
   DROP TABLE dbo.Grand_prix
   
IF OBJECT_ID (N'Grand_Prix_Name', N'U') IS NOT NULL 
   DROP TABLE dbo.Grand_Prix_Name

IF OBJECT_ID (N'Track', N'U') IS NOT NULL 
   DROP TABLE dbo.Track

IF OBJECT_ID (N'Sponsor', N'U') IS NOT NULL 
   DROP TABLE dbo.Sponsor

IF OBJECT_ID (N'Command', N'U') IS NOT NULL 
   DROP TABLE dbo.Command

IF OBJECT_ID (N'"Location"', N'U') IS NOT NULL 
   DROP TABLE dbo."Location"

IF OBJECT_ID (N'Country', N'U') IS NOT NULL 
   DROP TABLE dbo.Country

IF OBJECT_ID (N'Car', N'U') IS NOT NULL 
   DROP TABLE dbo.Car

IF OBJECT_ID (N'Chassic', N'U') IS NOT NULL 
   DROP TABLE dbo.Chassic

IF OBJECT_ID (N'Engine', N'U') IS NOT NULL 
   DROP TABLE dbo.Engine

IF OBJECT_ID (N'Tire', N'U') IS NOT NULL 
   DROP TABLE dbo.Tire

IF OBJECT_ID (N'Pilot', N'U') IS NOT NULL 
   DROP TABLE dbo.Pilot

IF OBJECT_ID (N'Championship', N'U') IS NOT NULL 
   DROP TABLE dbo.Championship
/*DROP TABLE dbo.Sponsor_Support, dbo.Pilot_Contract, dbo.Pilot_Result, dbo.Pilot_Accident , dbo.Command_Result -- n <--> n
DROP TABLE dbo.Pitstop, dbo.Grand_Prix_Result, dbo.Lap_Record, dbo.Track_Config, dbo.Accident, dbo.Grand_prix -- 1<--n
DROP TABLE dbo.Grand_Prix_Name, dbo.Track, dbo.Sponsor, dbo.Command,dbo."Location", dbo.Country  -- tire 2
DROP TABLE dbo.Car, dbo.Chassic, dbo.Engine, dbo.Tire, dbo.Pilot, dbo.Championship


*/

/* Create table */
-- Tables without foreing keys
CREATE TABLE Country (
	Country_id	int IDENTITY(1,1) NOT NULL,
	Country_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Country] 
PRIMARY KEY (Country_id) -- 
)
GO


CREATE TABLE Grand_Prix_Name(
	Grand_prix_name_id	int IDENTITY(1,1) NOT NULL,
	Grand_prix_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Grand_Prix_Name] 
PRIMARY KEY (Grand_prix_name_id	) -- 
)
GO

CREATE TABLE Sponsor (
	Sponsor_id	int IDENTITY(1,1) NOT NULL,
	Sponsor_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Sponsor] 
PRIMARY KEY (Sponsor_id) -- 
)
GO

CREATE TABLE Engine (
	Engine_id	int IDENTITY(1,1) NOT NULL,
	Engine_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Engine] 
PRIMARY KEY (Engine_id) -- 
)
GO

CREATE TABLE [Chassic] (
	Chassic_id	int IDENTITY(1,1) NOT NULL,
	Chassic_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Chassic] 
PRIMARY KEY (Chassic_id) -- 
)
GO


CREATE TABLE Tire (
	Tire_id	int IDENTITY(1,1) NOT NULL,
	Tire_class nvarchar(100) NOT NULL,
	Tire_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Tire] 
PRIMARY KEY (Tire_id) -- 
)
GO


CREATE TABLE Championship (
	Championship_id	int IDENTITY(1,1) NOT NULL,
	Championship_start_date date NOT NULL,
	Championship_end_date date NOT NULL,
	--CONSTRAINT [PK_Championship] 
PRIMARY KEY (Championship_id) -- 
)
GO

CREATE TABLE Pilot (
	Pilot_id	int IDENTITY(1,1) NOT NULL,
	Pilot_name	nvarchar(100)	NOT NULL,
-- CONSTRAINT [PK_PILOT] 
PRIMARY KEY (Pilot_id)
)
GO

 -- Tables with Foreign key


-- Location


CREATE TABLE [Location] (
	Location_id	int IDENTITY(1,1) NOT NULL,
	Location_name nvarchar(100) NOT NULL,
	Country_id	int NOT NULL,
	--CONSTRAINT [PK_Location] 
PRIMARY KEY (Location_id) -- 
)
GO

ALTER TABLE [Location]
    ADD CONSTRAINT Location_FK0 FOREIGN KEY (Country_id) 
		REFERENCES Country (Country_id) 

GO



--Track

CREATE TABLE Track (
	Track_id	int IDENTITY(1,1) NOT NULL,
	Location_id	int NOT NULL,
	Track_name nvarchar(100) NOT NULL,
	--CONSTRAINT [PK_Track] 
PRIMARY KEY (Track_id) -- 
)
GO

ALTER TABLE Track
    ADD CONSTRAINT Track_FK0 FOREIGN KEY (Location_id) 
		REFERENCES Location (Location_id) 

GO

--Car
--ALTER TABLE [dbo].[Car] DROP CONSTRAINT [Car_1_FK0]
--DROP TABLE dbo.Accident;  

CREATE TABLE Car (
	Car_id	int IDENTITY(1,1) NOT NULL,
	Car_name nvarchar(100) NOT NULL,
	Chassic_id	int NOT NULL,
	Engine_id	int NOT NULL,
	--CONSTRAINT [PK_Car] 
PRIMARY KEY (Car_id) -- 
)
GO



ALTER TABLE Car 
    ADD CONSTRAINT Car_1_FK0 FOREIGN KEY (Chassic_id) 
		REFERENCES Chassic(Chassic_id) 

GO

ALTER TABLE Car 
    ADD CONSTRAINT Car_2_FK0 FOREIGN KEY (Engine_id) 
		REFERENCES Engine(Engine_id) 

GO



--Grand_prix
CREATE TABLE Grand_Prix (
	Grand_prix_id	int IDENTITY(1,1) NOT NULL,
	Championship_id int NOT NULL,
	Grand_prix_name_id int NOT NULL,
	Grand_prix_date date NOT NULL,
	Track_id int NOT NULL,
	--CONSTRAINT [PK_Grand_Prix] 
PRIMARY KEY (Grand_prix_id) -- 
)
GO

ALTER TABLE Grand_Prix 
    ADD CONSTRAINT Grand_prix_1_FK0 FOREIGN KEY (Track_id) 
		REFERENCES Track (Track_id) 

GO


ALTER TABLE Grand_Prix 
    ADD CONSTRAINT Grand_prix_2_FK0 FOREIGN KEY (Championship_id) 
		REFERENCES Championship (Championship_id) 

GO


ALTER TABLE Grand_Prix 
    ADD CONSTRAINT Grand_prix_3_FK0 FOREIGN KEY (Grand_prix_name_id) 
		REFERENCES Grand_Prix_Name (Grand_prix_name_id) 

GO

--Grand_prix Result


CREATE TABLE Grand_Prix_Result (
	Grand_prix_id	int NOT NULL,
	Pilot_id	int  NOT NULL,
	Car_id	int  NOT NULL,
	Place	tinyint NOT NULL,
	Amount_of_laps int NOT NULL,
	"Time"	time ,
	Score	int ,
	--CONSTRAINT [PK_Grand_Prix_Result] 
PRIMARY KEY (Grand_prix_id, Pilot_id) -- 
)
GO

 
 ALTER TABLE Grand_Prix_Result 
    ADD CONSTRAINT Grand_prix_result_2_FK0 FOREIGN KEY (Car_id) 
		REFERENCES Car (Car_id) 

GO

 ALTER TABLE Grand_Prix_Result 
    ADD CONSTRAINT Grand_prix_result_1_FK0 FOREIGN KEY (Pilot_id) 
		REFERENCES Pilot (Pilot_id) 

GO

 ALTER TABLE Grand_Prix_Result 
    ADD CONSTRAINT Grand_prix_result_3_FK0 FOREIGN KEY (Grand_prix_id) 
		REFERENCES Grand_Prix (Grand_prix_id) 

GO

--Accident


CREATE TABLE Accident (
	Accident_id	int IDENTITY(1,1) NOT NULL,
	Accident_time	time NOT NULL,
	Grand_prix_id	int		NOT NULL,
	Accident_description nvarchar(1000) NOT NULL,
	--CONSTRAINT [PK_Accident] 
PRIMARY KEY (Accident_id) -- 
)
GO

ALTER TABLE Accident 
    ADD CONSTRAINT ACCIDENT_FK0 FOREIGN KEY (Grand_prix_id) 
		REFERENCES Grand_prix(Grand_prix_id)
		ON DELETE CASCADE ON UPDATE CASCADE

GO

--Pilot_accident

CREATE TABLE Pilot_Accident (
	Accident_id	int  NOT NULL,
	Pilot_id	int  NOT NULL,
	--CONSTRAINT [PK_Accident] 
PRIMARY KEY (Accident_id, Pilot_id) -- 

)
GO


ALTER TABLE Pilot_Accident 
    ADD CONSTRAINT Pilot_FK0 FOREIGN KEY (Pilot_id) 
		REFERENCES Pilot (Pilot_id)
		ON DELETE CASCADE ON UPDATE CASCADE

GO

ALTER TABLE Pilot_Accident 
    ADD CONSTRAINT Pilot_Accident_1_FK0 FOREIGN KEY (Accident_id) 
		REFERENCES Accident (Accident_id) 
		ON DELETE CASCADE ON UPDATE CASCADE

GO

--Pilot_result


CREATE TABLE Pilot_Result (
	Pilot_id	int  NOT NULL,
	Championship_id	int  NOT NULL,
	Place	tinyint NOT NULL,
	--CONSTRAINT [PK_Pilot_Result] 
PRIMARY KEY (Pilot_id,Championship_id) -- 
)
GO

ALTER TABLE Pilot_Result 
    ADD CONSTRAINT Pilot_Result_1_FK0 FOREIGN KEY (Pilot_id) 
		REFERENCES Pilot (Pilot_id) 

GO

ALTER TABLE Pilot_Result 
    ADD CONSTRAINT Pilot_Result_2_FK0 FOREIGN KEY (Championship_id) 
		REFERENCES Championship (Championship_id) 

GO


--Track Config

CREATE TABLE Track_Config (
	Track_id	int NOT NULL,
	Lap_lenght	decimal(10,3) NOT NULL,
	Turn_number	smallint NOT NULL,
	Config_start_date date NOT NULL,
	Config_end_date date NOT NULL,
	--CONSTRAINT [PK_Track_Config] 
PRIMARY KEY (Track_id,Config_start_date) -- 
)
GO


ALTER TABLE Track_Config 
    ADD CONSTRAINT Track_Config_FK0 FOREIGN KEY (Track_id) 
		REFERENCES Track (Track_id) 

GO

-- Lap_record
CREATE TABLE Lap_Record (
	Grand_prix_id	int  NOT NULL,
	Track_id	int NOT NULL,
	Lap_record_time time NOT NULL,
	--CONSTRAINT [PK_Lap_Record] 
PRIMARY KEY (Grand_prix_id,Track_id) -- 
)
GO

ALTER TABLE Lap_Record 
    ADD CONSTRAINT Lap_Record_1_FK0 FOREIGN KEY (Grand_prix_id) 
		REFERENCES Grand_Prix (Grand_prix_id) 

GO

ALTER TABLE Lap_Record 
    ADD CONSTRAINT Lap_Record_2_FK0 FOREIGN KEY (Track_id) 
		REFERENCES Track (Track_id) 

GO

--Pitstop


CREATE TABLE Pitstop (
	Grand_prix_id int  NOT NULL,
	Pilot_id int  NOT NULL,
	Pitstop_start_time time NOT NULL,
	Pitstop_end_time time NOT NULL,
	Tire_id int NOT NULL,
	--CONSTRAINT [PK_Pitstop] 
PRIMARY KEY (Grand_prix_id,Pilot_id,Pitstop_start_time) -- 
)
GO


ALTER TABLE Pitstop 
    ADD CONSTRAINT Pitstop_1_FK0 FOREIGN KEY (Grand_prix_id) 
		REFERENCES Grand_Prix (Grand_prix_id) 

GO

ALTER TABLE Pitstop 
    ADD CONSTRAINT Pitstop_2_FK0 FOREIGN KEY (Pilot_id) 
		REFERENCES Pilot (Pilot_id) 

GO

ALTER TABLE Pitstop 
    ADD CONSTRAINT Pitstop_3_FK0 FOREIGN KEY (Tire_id) 
		REFERENCES Tire (Tire_id) 
		ON UPDATE CASCADE

GO


-- Command
CREATE TABLE Command (
	Command_id	int IDENTITY(1,1) NOT NULL,
	Command_name nvarchar(100) NOT NULL,
	Command_site nvarchar(100) ,
	Country_id	int NOT NULL,
	--CONSTRAINT [PK_Command] 
PRIMARY KEY (Command_id) -- 
)
GO


ALTER TABLE Command 
    ADD CONSTRAINT Command_FK0 FOREIGN KEY (Country_id) 
		REFERENCES Country (Country_id) 

GO

--Command_result

CREATE TABLE Command_Result (
	Championship_id	int NOT NULL,
	Command_id int  NOT NULL,
	Place tinyint NOT NULL,
	--CONSTRAINT [PK_Commad_Result] 
PRIMARY KEY (Championship_id,Command_id) -- 
)
GO

ALTER TABLE Command_Result 
    ADD CONSTRAINT Command_result_1_FK0 FOREIGN KEY (Command_id) 
		REFERENCES Command (Command_id) 

GO

ALTER TABLE Command_Result 
    ADD CONSTRAINT Command_result_2_FK0 FOREIGN KEY (Championship_id) 
		REFERENCES Championship (Championship_id) 

GO

--Pilot Contract


CREATE TABLE Pilot_Contract (
	Pilot_id	int  NOT NULL,
	Contract_start_date date NOT NULL,
	Contract_end_date date ,
	Command_id	int NOT NULL,
	--CONSTRAINT [PK_Pilot_Contract] 
PRIMARY KEY (Pilot_id, Contract_start_date) -- 
)
GO


ALTER TABLE Pilot_Contract 
    ADD CONSTRAINT Pilot_Contract_FK0 FOREIGN KEY (Command_id) 
		REFERENCES Command (Command_id) 

GO

ALTER TABLE Pilot_Contract 
    ADD CONSTRAINT Pilot_Contract_1_FK0 FOREIGN KEY (Pilot_id) 
		REFERENCES Pilot (Pilot_id) 

GO

-- Sponsor_support

CREATE TABLE Sponsor_Support (
	Command_id	int  NOT NULL,
	Sponsor_id	int  NOT NULL,
	Sponsor_start_date date NOT NULL,
	Sponsor_end_date date NOT NULL,
	--CONSTRAINT [PK_Sponsor_Support] 
PRIMARY KEY (Command_id,Sponsor_id,Sponsor_start_date) -- 
)
GO

ALTER TABLE Sponsor_Support 
    ADD CONSTRAINT Sponsor_support_1_FK0 FOREIGN KEY (Command_id) 
		REFERENCES Command (Command_id) 
ON DELETE CASCADE
GO

ALTER TABLE Sponsor_Support 
    ADD CONSTRAINT Sponsor_support_2_FK0 FOREIGN KEY (Sponsor_id) 
		REFERENCES Sponsor (Sponsor_id) 
ON DELETE CASCADE
GO
--ALTER TABLE MyTable ALTER COLUMN NullCOl NVARCHAR(20) NOT NULL;
--check indentity
