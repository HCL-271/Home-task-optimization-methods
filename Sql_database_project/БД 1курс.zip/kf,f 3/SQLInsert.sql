--USE FORMULA_1_LAB
use ddblab0
SET DATEFORMAT dmy
GO

/* ���������� ������ � �������� */



-- ������� ������
DELETE Pilot_Contract
DELETE Pilot_Result
DELETE Command_Result
DELETE Lap_Record
DELETE Sponsor_Support
DELETE Sponsor
DELETE Command
DELETE Grand_Prix_Result
DELETE Pilot_Accident
DELETE Accident
DELETE Pitstop
DELETE Grand_Prix
DELETE Track_Config
DELETE Track
DELETE "Location"
DELETE Country
DELETE Grand_Prix_Name
DELETE Pilot
DELETE Car
DELETE Engine
DELETE Chassic
DELETE Championship
DELETE Tire

-- ����� ��������� ������ � id
DBCC CHECKIDENT(Accident, RESEED, 0)
DBCC CHECKIDENT(Country, RESEED, 0)
DBCC CHECKIDENT(Championship, RESEED, 0)
DBCC CHECKIDENT(Pilot, RESEED, 199)
DBCC CHECKIDENT(Track, RESEED, 0)
DBCC CHECKIDENT(Sponsor, RESEED, 1)
DBCC CHECKIDENT("Location", RESEED, 0)
DBCC CHECKIDENT(Grand_Prix_Name, RESEED, 0)
DBCC CHECKIDENT(Engine, RESEED, 299)
DBCC CHECKIDENT(Chassic, RESEED, 299)
DBCC CHECKIDENT(Car, RESEED, 399)
DBCC CHECKIDENT(Grand_Prix, RESEED, 0)
DBCC CHECKIDENT(Tire, RESEED, 99)
DBCC CHECKIDENT(Command, RESEED, 99)
DBCC CHECKIDENT(Sponsor, RESEED, 0)


/* ���������� ������ */

INSERT INTO [Country](country_name) VALUES ('��������������');
INSERT INTO [Country](country_name) VALUES ('��������'      );
INSERT INTO [Country](country_name) VALUES ('���������'     );
INSERT INTO [Country](country_name) VALUES ('����������'    );
INSERT INTO [Country](country_name) VALUES ('���������'     );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('�����'         );
INSERT INTO [Country](country_name) VALUES ('�������'       );
INSERT INTO [Country](country_name) VALUES ('�������'       );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('�������'       );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('�������'       );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('�������'       );
INSERT INTO [Country](country_name) VALUES ('�����'        );
INSERT INTO [Country](country_name) VALUES ('�����������'        );
INSERT INTO [Country](country_name) VALUES ('������'        );
INSERT INTO [Country](country_name) VALUES ('�������'        );
INSERT INTO [Country](country_name) VALUES ('��������'        );
INSERT INTO [Country](country_name) VALUES ('�������'        );
INSERT INTO [Country](country_name) VALUES ('��������'        );
INSERT INTO [Country](country_name) VALUES ('���-����'        );
INSERT INTO [Country](country_name) VALUES ('���'        );
INSERT INTO [Country](country_name) VALUES ('�����'        );


INSERT INTO [Location](Location_name, Country_id) VALUES ('��������', 4);
INSERT INTO [Location](Location_name, Country_id) VALUES ('�����',  17 );
INSERT INTO [Location](Location_name, Country_id) VALUES ('������',  18 );
INSERT INTO [Location](Location_name, Country_id) VALUES ('����',  19 );
INSERT INTO [Location](Location_name, Country_id) VALUES ('���������',   8);
INSERT INTO [Location](Location_name, Country_id) VALUES ('�����-�����',  20 );
INSERT INTO [Location](Location_name, Country_id) VALUES ('��������', 12  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('���� �����', 9  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('���������', 15  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('������������',1   );
INSERT INTO [Location](Location_name, Country_id) VALUES ('����������', 2  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('�����������', 21  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('���',11   );
INSERT INTO [Location](Location_name, Country_id) VALUES ('�����',6   );
INSERT INTO [Location](Location_name, Country_id) VALUES ('������-���',22   );
INSERT INTO [Location](Location_name, Country_id) VALUES ('����', 14  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('������', 16  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('�����',  26 );
INSERT INTO [Location](Location_name, Country_id) VALUES ('�������', 23  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('��������', 24  );
INSERT INTO [Location](Location_name, Country_id) VALUES ('��-������', 25  );

INSERT INTO Track(Track_name, Location_id) VALUES ('�������-����',1 );
INSERT INTO Track(Track_name, Location_id) VALUES ('Bahrain International Circuit',   2);
INSERT INTO Track(Track_name, Location_id) VALUES ('Shanghai International Circuit', 3   );
INSERT INTO Track(Track_name, Location_id) VALUES ('����',  4 );
INSERT INTO Track(Track_name, Location_id) VALUES ('���������',   5);
INSERT INTO Track(Track_name, Location_id) VALUES ('������',   6);
INSERT INTO Track(Track_name, Location_id) VALUES ('Circuit Gilles Villeneuve', 7  );
INSERT INTO Track(Track_name, Location_id) VALUES ('Circuit Paul Ricard	',  8 );
INSERT INTO Track(Track_name, Location_id) VALUES ('Red Bull Ring',  9 );
INSERT INTO Track(Track_name, Location_id) VALUES ('������������',   10);
INSERT INTO Track(Track_name, Location_id) VALUES ('����������	',   11);
INSERT INTO Track(Track_name, Location_id) VALUES ('�����������', 12  );
INSERT INTO Track(Track_name, Location_id) VALUES ('���', 13  );
INSERT INTO Track(Track_name, Location_id) VALUES ('Monza Autodrome',  14 );
INSERT INTO Track(Track_name, Location_id) VALUES ('��������',  15 );
INSERT INTO Track(Track_name, Location_id) VALUES ('���� ��������',   16);
INSERT INTO Track(Track_name, Location_id) VALUES ('������',   17);
INSERT INTO Track(Track_name, Location_id) VALUES ('Circuit of the Americas', 18  );
INSERT INTO Track(Track_name, Location_id) VALUES ('����������',    20);
INSERT INTO Track(Track_name, Location_id) VALUES ('����� ������� ��������',   19);
INSERT INTO Track(Track_name, Location_id) VALUES ('�c-������',   21);


INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (21, 5554, 55, '23-11-2018', '25-11-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (20 , 4309,71 ,'09-11-2018' ,'11-11-2018' );
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (19, 4304, 71, '26-10-2018', '28-10-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (18 , 5513, 56, '19-10-2018', '22-10-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (17, 5807, 53, '05-10-2018', '07-10-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (16,5848 ,53 , '28-09-2018', '30-09-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (15, 5063 ,61, '14-09-2018', '16-09-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (14,5793 ,53 , '31-08-2018', '02-09-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (13,7004 ,44 , '24-08-2018', '26-08-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (12, 4381,70 , '27-07-2018', '29-07-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (11,4574 , 67, '20-07-2018', '22-07-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (10,5891 ,52 , '06-07-2018', '08-07-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (9, 4318,71 , '29-07-2018', '01-07-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (8, 5842,53 , '22-06-2018', '24-06-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (7, 4361,70 , '08-06-2018', '10-06-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (6, 3337, 78, '24-05-2018', '27-05-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (5,4655 ,66 , '11-05-2018', '13-05-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (4,6003 , 51, '27-04-2018', '29-04-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (3, 5451,56 , '13-04-2018', '15-04-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (2, 5412 , 57, '06-04-2018', '08-04-2018');
INSERT INTO Track_Config(Track_id, Lap_lenght, Turn_number, Config_start_date, Config_end_date) VALUES (1,5303 ,59 , '23-03-2018', '25-03-2018');


INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ���������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ��������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �����');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ��������������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ��������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ���������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ���');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� �������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ��������');
INSERT INTO Grand_Prix_Name(Grand_Prix_Name) VALUES ('���� ��� ���-����');

INSERT INTO Pilot(Pilot_name) VALUES ('��������� �������');
INSERT INTO Pilot(Pilot_name) VALUES ('���� ��������');
INSERT INTO Pilot(Pilot_name) VALUES ('������ �����');
INSERT INTO Pilot(Pilot_name) VALUES ('������� ����');
INSERT INTO Pilot(Pilot_name) VALUES ('����� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('����� ���������');
INSERT INTO Pilot(Pilot_name) VALUES ('�������� �������');
INSERT INTO Pilot(Pilot_name) VALUES ('�������� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('����� ��������');
INSERT INTO Pilot(Pilot_name) VALUES ('�������� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('������� ��������');
INSERT INTO Pilot(Pilot_name) VALUES ('���� ����������');
INSERT INTO Pilot(Pilot_name) VALUES ('���� �����������');
INSERT INTO Pilot(Pilot_name) VALUES ('������ �����');
INSERT INTO Pilot(Pilot_name) VALUES ('������ ��������');
INSERT INTO Pilot(Pilot_name) VALUES ('����� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('���� �����');
INSERT INTO Pilot(Pilot_name) VALUES ('������� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('���� ������');
INSERT INTO Pilot(Pilot_name) VALUES ('������ ��������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������ ����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������ �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '����� ����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������ �����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '���� ����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������� ����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '��������� �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '�� �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '���� �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������� �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '���� ��������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������� �����');
INSERT INTO [Pilot](Pilot_name) VALUES ( '��� ������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '�������� �������');
INSERT INTO [Pilot](Pilot_name) VALUES ( '������ ��������');

INSERT INTO Engine(Engine_name) VALUES ('Ferrari 059/3 1,6 V6T');
INSERT INTO Engine(Engine_name) VALUES ('Mercedes Hybrid PU106A 1,6 V6T');
INSERT INTO Engine(Engine_name) VALUES ('Renault Energy F1 1,6 V6T ');
INSERT INTO Engine(Engine_name) VALUES ('Mercedes M09 EQ Power+ 1,6 V6');
INSERT INTO Engine(Engine_name) VALUES ('TAG Heuer (Renault RE18) 1,6 V6T');
INSERT INTO Engine(Engine_name) VALUES ('Renault RE18 1.6 V6T');
INSERT INTO Engine(Engine_name) VALUES ('Toleman TG184');
INSERT INTO Engine(Engine_name) VALUES ('Renault R.E.17 1,6 V6T');
INSERT INTO Engine(Engine_name) VALUES ('Ferrari 062 1,6 V6');
INSERT INTO Engine(Engine_name) VALUES ('Ferrari 063 1,6 V6');
INSERT INTO Engine(Engine_name) VALUES ('Mercedes M08 EQ Power+ 1,6 V6');
INSERT INTO Engine(Engine_name) VALUES ('Ferrari 064 EVO 1.6 V6 t');
INSERT INTO Engine(Engine_name) VALUES ('Honda RA618H');
--INSERT INTO Engine(Engine_name) VALUES ('');


INSERT INTO Chassic(Chassic_name) VALUES ('Red Bull RB14');
INSERT INTO Chassic(Chassic_name) VALUES ('R.S.18');
INSERT INTO Chassic(Chassic_name) VALUES ('R30');
INSERT INTO Chassic(Chassic_name) VALUES ('Benetton B200B');
INSERT INTO Chassic(Chassic_name) VALUES ('Benetton B200');
INSERT INTO Chassic(Chassic_name) VALUES ('Toro Rosso STR12');
INSERT INTO Chassic(Chassic_name) VALUES ('Toro Rosso STR11');
INSERT INTO Chassic(Chassic_name) VALUES ('Toro Rosso STR10');
INSERT INTO Chassic(Chassic_name) VALUES ('Ferrari SF71H');
INSERT INTO Chassic(Chassic_name) VALUES ('Ferrari SF16-H');
INSERT INTO Chassic(Chassic_name) VALUES ('Sauber C37');
INSERT INTO Chassic(Chassic_name) VALUES ('Sauber C36');
INSERT INTO Chassic(Chassic_name) VALUES ('VJM 12');
INSERT INTO Chassic(Chassic_name) VALUES ('VJM 11');
INSERT INTO Chassic(Chassic_name) VALUES ('Apollon-Williams FW03');
INSERT INTO Chassic(Chassic_name) VALUES ('Williams FW11');
INSERT INTO Chassic(Chassic_name) VALUES ('Mclaren 720s');
INSERT INTO Chassic(Chassic_name) VALUES ('McLaren 650S');
INSERT INTO Chassic(Chassic_name) VALUES ('McLaren MP4-12C');
INSERT INTO Chassic(Chassic_name) VALUES ('Mercedes F1 W03');
INSERT INTO Chassic(Chassic_name) VALUES ('Mercedes MGP W01');

INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('Ferrari SF71H', 308 , 309 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('VJM11', 320 , 303 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('Haas VF-19', 309  , 312 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('McLaren MCL33', 301  , 306 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('Mercedes AMG F1 W09 EQ Power+', 320 , 303 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('Red Bull RB14', 305 , 300 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('R.S.18', 301 , 306  );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('Sauber C37', 310 , 309 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('STR13', 313 ,  312 );
INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('FW41', 315 , 303 );
--INSERT INTO Car(Car_name,Chassic_id,Engine_id) VALUES ('',  ,  );


INSERT INTO Championship(Championship_start_date, Championship_end_date) VALUES ('23-03-2018', '25-11-2018');
INSERT INTO Championship(Championship_start_date, Championship_end_date) VALUES ('15-03-2019', '01-12-2019');
INSERT INTO Championship(Championship_start_date, Championship_end_date) VALUES ('15-03-2020', '01-12-2020');
--INSERT INTO Championship(Championship_start_date, Championship_end_date) VALUES ('', '');

INSERT INTO Grand_Prix VALUES( 1,1 , '23-03-2018', 1);
INSERT INTO Grand_Prix VALUES( 1,2 , '06-04-2018', 2);
INSERT INTO Grand_Prix VALUES( 1, 3, '13-04-2018', 3);
INSERT INTO Grand_Prix VALUES( 1, 4, '27-04-2018', 4);
INSERT INTO Grand_Prix VALUES( 1, 5, '11-05-2018', 5);
INSERT INTO Grand_Prix VALUES( 1,6 , '24-05-2018', 6);
INSERT INTO Grand_Prix VALUES( 1,7 , '08-06-2018', 7);
INSERT INTO Grand_Prix VALUES( 1, 8, '22-06-2018', 8);
INSERT INTO Grand_Prix VALUES( 1, 9, '29-07-2018', 9);
INSERT INTO Grand_Prix VALUES( 1, 10, '06-07-2018', 10);
INSERT INTO Grand_Prix VALUES( 1, 11, '20-07-2018', 11);
INSERT INTO Grand_Prix VALUES( 1,12 , '27-07-2018', 12);
INSERT INTO Grand_Prix VALUES( 1,13 , '24-08-2018', 13);
INSERT INTO Grand_Prix VALUES( 1, 14, '31-08-2018', 14);
INSERT INTO Grand_Prix VALUES( 1, 15, '14-09-2018', 15);
INSERT INTO Grand_Prix VALUES( 1, 16, '28-09-2018', 16);
INSERT INTO Grand_Prix VALUES( 1, 17, '05-10-2018', 17);
INSERT INTO Grand_Prix VALUES( 1, 18, '19-10-2018', 18);
INSERT INTO Grand_Prix VALUES( 1, 19, '26-10-2018', 19);
INSERT INTO Grand_Prix VALUES( 1, 20, '09-11-2018', 20);
INSERT INTO Grand_Prix VALUES( 1,21 , '23-11-2018', 21);

INSERT INTO Grand_Prix VALUES( 1,1 , '20-07-2020',1 );
INSERT INTO Grand_Prix VALUES( 1, 2, '31-08-2020',2 );
INSERT INTO Grand_Prix VALUES( 1, 3, '14-09-2020',3 );
INSERT INTO Grand_Prix VALUES( 1, 4, '08-06-2020',4 );
INSERT INTO Grand_Prix VALUES( 1, 5, '26-10-2020',5 );
INSERT INTO Grand_Prix VALUES( 1, 6, '23-11-2020',6 );
--INSERT INTO Grand_Prix VALUES( 1, , '', );
--SELECT * FROM Grand_prix

INSERT INTO Tire(Tire_class, Tire_name) VALUES('Superhard', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hard', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Soft', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Supersoft', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Medium', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Ultrasoft', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hypersoft', 'Michelin');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Superhard', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hard', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Soft', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Supersoft', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Medium', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Ultrasoft', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hypersoft', 'GoodYear');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Superhard', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hard', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Soft', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Supersoft', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Medium', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Ultrasoft', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hypersoft', 'Bridgestone');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Superhard', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hard', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Soft', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Supersoft', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Medium', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Ultrasoft', 'Gachaking');
INSERT INTO Tire(Tire_class, Tire_name) VALUES('Hypersoft', 'Gachaking');

	--SElect* from tire

INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES(1 , 200, '00:12:11.847', '00:12:23.948' , 103);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,208 , '00:24:10.402', '00:24:23.490', 104);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,201 ,'00:21:11.201', '00:21:45.001', 113);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 210, '00:48:12.038', '00:48:34.238' , 104);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,207 , '00:32:09.124', '00:32:31.039' , 103);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 211, '00:57:49.011', '00:58:01.009' , 103);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,212 , '00:14:33.163', '00:14:57.024' , 108);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,209 , '01:02:12.092', '01:02:51.995' , 102);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 206,  '00:32:09.911', '00:32:44.799' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,213 , '00:59:45.945', '01:00:04.221' , 111);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 202, '01:08:22.928', '01:08:59.210' , 112);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 203, '00:48:12.038', '00:48:34.238' , 114);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 215,'00:55:08.463', '00:55:34.019' , 116);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 218,  '00:32:09.911', '00:32:44.799' , 117);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1,217 , '00:21:52.990', '00:22:23.331', 118);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 204, '00:56:41.231', '00:56:59.992' , 119);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 205, '00:10:37.837', '00:10:57.001' , 120);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 1, 216, '01:05:39.023', '01:05:57.750' , 121);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 200, '01:06:39.023', '01:08:57.750' , 113);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 201, '01:06:39.023', '01:09:57.750' , 112);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 211, '01:07:39.023', '01:10:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 213, '01:08:39.023', '01:11:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 227, '01:09:39.023', '01:12:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 225, '01:10:39.023', '01:13:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 224, '01:11:39.023', '01:14:57.750' , 112);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 221, '01:12:39.023', '01:15:57.750' , 101);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 212, '01:13:39.023', '01:16:57.750' , 102);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2, 207, '01:14:39.023', '01:17:57.750' , 127);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,200 , '01:15:39.023', '01:18:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,201 , '01:16:39.023', '01:19:57.750' , 101);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,206 , '01:17:39.023', '01:20:57.750' , 102);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,212 , '01:18:39.023', '01:21:57.750' , 103);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,229 , '01:19:39.023', '01:22:57.750' , 104);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,219 , '01:20:39.023', '01:23:57.750' , 105);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,218 , '01:21:39.023', '01:24:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 3,232 , '01:22:39.023', '01:25:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 2,229 , '01:23:39.023', '01:26:57.750' , 100);

INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 4,231 , '01:24:39.023', '01:27:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 5,230 , '01:25:39.023', '01:28:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 4,231 , '01:26:39.023', '01:29:57.750' , 100);
INSERT INTO Pitstop(Grand_prix_id, Pilot_id, Pitstop_start_time, Pitstop_end_time, Tire_id) VALUES( 5,203 , '01:27:39.023', '01:30:57.750' , 112);

--SELECT * FROM Grand_Prix_Result



INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (1,  '������� ������', '00:02:05.223');
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (5,  '����� ������ � ������', '00:55:04.204'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (8,  'o���� ���������','00:51:01.834'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (6,  '����� ������ � ������', '00:29:45.135'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (17,  '������������ �� ������ ����', '00:54:09.632'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (21,  '����� ������ � ������ ������ � ������������', '01:04:11.309'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (13,  '���������� ������ ������ ������', '00:32:05.727'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (5,  '�������� �� ��������� ������ c����� � ������������', '00:27:05.223'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (4,  '����� ������ � ������ ������ � ������������', '00:11:19.338'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (14,  '������� ������ ������', '00:21:21.044'); 

INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (14,  '������� ������ ������', '00:22:21.044'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (13,  '������� ������ ������', '00:23:21.044'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (14,  '������� ������ ������', '00:24:21.044'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (14,  '������� ������ ������', '00:25:21.044'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (14,  '������� ������ ������', '00:26:21.044'); 
INSERT INTO Accident(Grand_prix_id, Accident_description, Accident_time) VALUES (1,  '������� ������ ������', '00:27:21.044'); 

INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 1, 212);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 2,201);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 3,203);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 4,213);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 5,207);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 6,208);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 7,209);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 8,201);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 9,208);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 10,210);

INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 11,212);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 12,232);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 13,231);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 14,229);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 15,219);
INSERT INTO Pilot_Accident(Accident_id, Pilot_id) VALUES ( 16,203);

--SELECT * FROM Grand_Prix_Result
--SELECT * from Grand_Prix

INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,200 ,402 , 1,   '01:23:39.654', 25, 55 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 , 232,404 , 14,  '01:38:19.624', NULL, 54);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,202 , 403, 20,   '01:31:34.738', NULL, 53 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,203 ,405 , 2,   '01:23:41.238' , 18, 52);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,204 ,406 ,  19,   '01:31:29.957', NULL,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,205 ,409 , 18,   '01:31:29.010' , NULL,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,206 ,408 , 17,   '01:31:28.620', NULL ,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,207 ,400 ,  16,   '01:31:28.231', NULL ,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,208 ,401 , 15,  NULL, NULL ,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,209 ,403 , 13,  '01:35:22.014' , NULL,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,210 ,406 ,  4,   '01:23:49.044' , 12,54);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,211 ,408 , 5,   '01:24:01.541' , 10,52);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,212 ,402 ,  6,   '01:24:34.259', 8, 51);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,213 ,404 , 7,   '01:24:59.981' , 6, 55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,214 ,406 ,  12,  '01:34:41.512', NULL,51);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,215,409 , 11,  '01:33:32.004' , NULL,40);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,216 ,405 ,10,  '01:28:21.214' , 1,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,217 ,401 , 8,   '01:26:48.210', 4,55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,218 ,403 , 3,   '01:23:45.097', 15, 53 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (1 ,219 ,408 , 9,   '01:26:57.124', 2, 53);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,229 ,400 , 1,   '01:43:32.004',25 , 54);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,200 , 401, 2,   '01:44:32.004', 18, 56);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,201 ,405 , 3,   '01:45:32.004', 15, 55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,219 ,407 , 4,   '01:46:32.004', 12, 54);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,228 ,409 , 5,   '01:47:32.004', 10, 55);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,227 ,408 , 6,   '01:48:32.004', 8, 53);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,226 ,401 , 7,   '01:49:32.004', 6, 26);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,225 ,401 , 8,   '01:50:32.004', 4, 56);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,211 ,402 , 9,   '01:51:32.004', 2, 51);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (2 ,218 ,403 , 10,   '01:52:32.004', 1, 49);


INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 , 229 ,400 ,1 ,   '01:24:41.238', 25,56 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,219 ,401 ,2 ,   '01:25:41.238',18 ,55 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,232 , 402,3 ,   '01:26:41.238', 15, 54);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,206 ,403 ,4 ,   '01:27:41.238',12 , 53);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,201 ,404 ,5 ,   '01:28:41.238',10 , 51);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,213 ,405 ,6 ,   '01:29:41.238',8 ,52 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,216 ,406 ,7 ,   '01:30:41.238',6 ,50 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,225 ,407 ,8 ,   '01:31:41.238',4 ,49 );
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,212 ,408 ,9 ,   '01:32:41.238',2 , 48);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (3 ,218 ,409 ,10,   '01:33:41.238',1 , 47);

INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,230 ,400 ,1,   '01:35:41.238',25 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,231 ,401 ,2,   '01:35:41.238',18 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,203 ,402 ,3,   '01:35:41.238',15 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,232 ,403 ,4,   '01:35:41.238',12 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,214 ,403 ,5,   '01:35:41.238',10 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,201 ,405 ,6,   '01:35:41.238',8 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,229 ,406 ,7,   '01:35:41.238',6 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,217 ,407 ,8,   '01:35:41.238',4 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,216 ,409 ,9,   '01:35:41.238',2 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,218 ,400 ,10,   '01:35:41.238',1 , 49);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (4 ,227 ,408 ,11,   '01:35:41.238',0 , 49);

INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,230 ,400 ,1,   '01:36:41.238',25 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,231 ,400 ,2,   '01:37:41.238', 18, 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,234 ,400 ,3,   '01:38:41.238',15 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,229 ,400 ,4,   '01:39:41.238',12 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,219 ,400 ,5,   '01:40:41.238',10 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,200 ,400,6,   '01:41:41.238',8 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,201 ,400 ,7,   '01:42:41.238',6 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,203 ,400 ,8,   '01:43:41.238',4 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,205 ,400 ,9,   '01:44:41.238',2 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,204 ,400 ,10,   '01:45:41.238',1 , 38);
INSERT INTO Grand_Prix_Result(Grand_prix_id, Pilot_id, Car_id, Place, [Time], Score, Amount_of_laps) VALUES (5 ,206 ,400 ,11,   '01:46:41.238',0 , 38);


/*SELECT *
		FROM Country
		INNER JOIN Command ON Command.Country_id = Country.Country_id
		INNER JOIN Pilot_Contract ON Pilot_Contract.Command_id = Command.Command_id
		INNER JOIN Pilot ON Pilot.Pilot_id = Pilot_Contract.Pilot_id
		*/
INSERT INTO Command(Command_name ,country_id, command_site) VALUES ('��������',     2,   'http://mercedesamgf1.com'   );
INSERT INTO Command(Command_name, country_id,  command_site) VALUES ('��������',     26,    'http://cars.mclaren.com');
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('�������',      1,  'http://williams.co.uk'   );
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('���� �����',27  ,    NULL    );
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('������',       2,   'http://sauber.ch'    );
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('�������',      8,  'https://formula1.ferrari.com'   );
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('���� �����',   14,  'http://scuderiatororosso.redbull.com' );
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('��������',     12,    NULL);
INSERT INTO Command(Command_name ,country_id,  command_site) VALUES ('����',         18,  'https://www.renaultsport.com/'  );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('��� ����',     26,    'https://www.redbull.com/'    );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('������������ �����',     17,    'https://www.KonodioDa.com/'    );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('����������� �������� ����',     4,    'https://www.StardustCrusaders.com/'    );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('�������� �����',     18,    'https://www.stoneocean.com/'    );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('����������',     19,    'https://www.jojolion.com/'    );
INSERT INTO Command(Command_name, country_id, command_site) VALUES ('������� �����',     8,    'https://www.goldenwind.com/'    );
SELECT * FROM Country

INSERT INTO Sponsor(Sponsor_name) VALUES ('Honda');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Toyota');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Redbull');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Intel');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Mersedes-Benz');
INSERT INTO Sponsor(Sponsor_name) VALUES ('BMW - group');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Malboro');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Renault');
INSERT INTO Sponsor(Sponsor_name) VALUES ('Vodafone');

INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES ( 3,109 , '13-03-2017 ' , '13-03-2020 ');
INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES (5 ,100 , '19-09-2016 ' , '20-09-2018 ');
INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES ( 8,105 , '07-01-2018 ' , '06-01-2019 ');
INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES ( 4,106 , '27-02-2018 ' , '27-02-2021 ');

SELECT * FROM Sponsor_Support

INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (200 ,1 ,1 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (208 ,1 ,2 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (210 ,1 ,3 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (209 ,1 ,4 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (206 ,1 ,5 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (215 ,1 ,6 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (207 ,1 ,7 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (202 ,1 ,8 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (217 ,1 ,9 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (218 ,1 ,10 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (201 ,1 ,11 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (216 ,1 ,12 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (214 ,1 ,13 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (205 ,1 ,14 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (213 ,1 ,15 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (212 ,1 ,16 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (203 ,1 ,17 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (204 ,1 ,18 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (219 ,1 ,19 );
INSERT INTO Pilot_Result(Pilot_id, Championship_id, Place) VALUES (211 ,1 ,20 );


INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (201, 102, '14-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (201, 105, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (202, 103, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (203, 101, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (204, 108, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (205, 109, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (206, 101, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (206, 107, '11-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (207, 104, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (208, 106, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (208, 109, '16-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (209, 101, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (210, 106, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (211, 103, '15-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (212, 107, '11-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (213, 109, '14-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (214, 103, '13-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (215, 101, '12-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (215, 105, '17-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (216, 102, '16-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (216, 109, '17-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (217, 104, '11-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (218, 101, '19-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (219, 106, '18-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (220, 101, '10-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (221, 105, '11-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (222, 109, '12-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (223, 107, '13-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (224, 109, '14-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (225, 102, '16-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (226, 108, '15-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (227, 104, '19-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (228, 105, '19-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (229, 107, '20-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (230, 110, '21-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (231, 111, '22-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (232, 112, '23-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (233, 113, '24-12-2017');
INSERT INTO Pilot_Contract(pilot_id, command_id, Contract_start_date) VALUES (234, 114, '25-12-2017');


--SELECT * FROM Command
--SELECT * FROM PILOT
--Select * FROM Sponsor
