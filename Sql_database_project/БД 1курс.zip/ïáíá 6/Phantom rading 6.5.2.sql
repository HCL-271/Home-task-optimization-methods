USE FORMULA_1_LAB
GO
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ 
--SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRAN;

INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES ( 3,109 , '13-03-2017 ' , '13-03-2020 ');
INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES (5 ,100 , '19-09-2016 ' , '20-09-2018 ');

COMMIT TRAN;