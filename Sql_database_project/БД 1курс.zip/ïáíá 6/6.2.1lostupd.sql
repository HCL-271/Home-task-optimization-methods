USE FORMULA_1_LAB
GO



--t2
--select * from example
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
BEGIN TRAN;

DECLARE @v INT;

SELECT @v = Command_id
FROM Sponsor_Support
WHERE Sponsor_id = 8;

UPDATE Sponsor_Support 
SET Command_id = @v + 7
WHERE Sponsor_id = 8;

COMMIT TRAN;

SELECT Command_id
FROM Sponsor_Support
WHERE Sponsor_id = 8;