USE FORMULA_1_LAB
GO

IF OBJECT_ID (N'Sponsor_Support', N'U') IS NOT NULL 
   DROP TABLE dbo.Sponsor_Support

CREATE TABLE Sponsor_Support (
	Command_id	int  NOT NULL,
	Sponsor_id	int  NOT NULL,
	Sponsor_start_date date NOT NULL,
	Sponsor_end_date date NOT NULL,
	--CONSTRAINT [PK_Sponsor_Support] 
PRIMARY KEY (Command_id,Sponsor_id,Sponsor_start_date) -- 
)
GO

ALTER TABLE Sponsor_Support 
    ADD CONSTRAINT Sponsor_support_1_FK0 FOREIGN KEY (Command_id) 
		REFERENCES Command (Command_id) 
ON DELETE CASCADE
GO

ALTER TABLE Sponsor_Support 
    ADD CONSTRAINT Sponsor_support_2_FK0 FOREIGN KEY (Sponsor_id) 
		REFERENCES Sponsor (Sponsor_id) 
ON DELETE CASCADE
GO

INSERT INTO Sponsor_Support(Sponsor_id,Command_id, Sponsor_start_date, Sponsor_end_date) VALUES ( 8,105 , '07-01-2018 ' , '06-01-2019 ');

--t1
--SET TRANSACTION ISOLATION LEVEL READ COMMITTED
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRAN;

SELECT Command_id
FROM Sponsor_Support
WHERE Sponsor_id = 8;

WAITFOR DELAY '00:00:10';

SELECT Command_id 
FROM Sponsor_Support
WHERE Sponsor_id = 8;

COMMIT TRAN;