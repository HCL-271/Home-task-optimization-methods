USE FORMULA_1_LAB
GO

--t2
BEGIN TRAN;

UPDATE Sponsor_Support 
SET Command_id = 101
WHERE Sponsor_id = 8;

COMMIT TRAN;