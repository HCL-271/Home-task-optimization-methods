USE FORMULA_1_LAB
GO

--t2
BEGIN TRAN;



UPDATE Sponsor_Support 
SET Command_id = Command_id + 1
WHERE Sponsor_id = 8;

COMMIT TRAN;

SELECT Command_id
FROM Sponsor_Support
WHERE Sponsor_id = 8