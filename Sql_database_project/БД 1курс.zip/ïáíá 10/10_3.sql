use ddblab0
go

SET SHOWPLAN_XML ON;  
GO  
SET SHOWPLAN_XML OFF;  
GO  


-- ������ ��� �������� ��������
/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
*/


SET SHOWPLAN_ALL ON
GO

select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
	GO
SET SHOWPLAN_ALL OFF
GO

create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(orderID, orderdate, customerID)
create clustered index orrdet_clust on orderdetails1(productID, quantity, orderID)
create clustered index prod_clust on products1(unitprice, productID)
GO
SET SHOWPLAN_ALL ON
GO
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
GO
SET SHOWPLAN_ALL OFF
GO


drop index cust_clust on customers1
drop index ord_clust on orders1
drop index orrdet_clust on orderdetails1
drop index prod_clust on products1

-----------------
/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF

create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(orderID, orderdate, customerID)
create clustered index orrdet_clust on orderdetails1(productID, quantity, orderID)
create clustered index prod_clust on products1(unitprice, productID)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF

drop index cust_clust on customers1
drop index ord_clust on orders1
drop index orrdet_clust on orderdetails1
drop index prod_clust on products1

*/
SET SHOWPLAN_ALL ON
GO

select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
	GO
SET SHOWPLAN_ALL OFF
GO

create nonclustered index cust_nonclust on customers1(country, customerID) include (companyName)
create nonclustered index ord_nonclust on orders1(orderID, orderdate, customerID)
create nonclustered index orrdet_nonclust on orderdetails1(productID, quantity, orderID) include(discount)
create nonclustered index prod_nonclust on products1(unitprice, productID) include (ProductName)


GO
SET SHOWPLAN_ALL ON
GO
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
GO
SET SHOWPLAN_ALL OFF
GO

drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index orrdet_nonclust on orderdetails1
drop index prod_nonclust on products1
-------------------
/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF


create nonclustered index cust_nonclust on customers1(country, customerID) include (companyName)
create nonclustered index ord_nonclust on orders1(orderID, orderdate, customerID)
create nonclustered index orrdet_nonclust on orderdetails1(productID, quantity, orderID) include(discount)
create nonclustered index prod_nonclust on products1(unitprice, productID) include (ProductName)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF


drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index orrdet_nonclust on orderdetails1
drop index prod_nonclust on products1

*/
SET SHOWPLAN_ALL ON
GO
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
	GO
SET SHOWPLAN_ALL OFF
GO

create nonclustered index cust_nonclust on customers1(country, customerID) include (companyName)
create nonclustered index ord_nonclust on orders1(orderID, orderdate, customerID)
create nonclustered index orrdet_nonclust on orderdetails1(productID, quantity, orderID) include(discount)
create nonclustered index prod_nonclust on products1(unitprice, productID) include (ProductName)
create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(orderID, orderdate, customerID)
create clustered index orrdet_clust on orderdetails1(productID, quantity, orderID)
create clustered index prod_clust on products1(unitprice, productID)


GO
SET SHOWPLAN_ALL ON
GO
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
GO
SET SHOWPLAN_ALL OFF
GO

drop index cust_clust on customers1
drop index ord_clust on orders1
drop index orrdet_clust on orderdetails1
drop index prod_clust on products1
drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index orrdet_nonclust on orderdetails1
drop index prod_nonclust on products1

/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF


create nonclustered index cust_nonclust on customers1(country, customerID) include (companyName)
create nonclustered index ord_nonclust on orders1(orderID, orderdate, customerID)
create nonclustered index orrdet_nonclust on orderdetails1(productID, quantity, orderID) include(discount)
create nonclustered index prod_nonclust on products1(unitprice, productID) include (ProductName)
create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(orderID, orderdate, customerID)
create clustered index orrdet_clust on orderdetails1(productID, quantity, orderID)
create clustered index prod_clust on products1(unitprice, productID)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select prod.ProductName, orddet.discount, ord.orderdate, cust.companyName
from products1 as prod
	join orderdetails1 as orddet on orddet.productID = prod.productID
	join orders1 as ord on ord.orderID = orddet.orderID
	join customers1 as cust on ord.customerID = cust.customerID
where cust.country = 'USA'
	and ord.orderdate between '19950923' and '19980730'
	and orddet.quantity >= 5
	and prod.unitprice >= 10
SET STATISTICS IO OFF
SET STATISTICS TIME OFF


drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index orrdet_nonclust on orderdetails1
drop index prod_nonclust on products1

drop index cust_clust on customers1
drop index ord_clust on orders1
drop index orrdet_clust on orderdetails1
drop index prod_clust on products1

*/