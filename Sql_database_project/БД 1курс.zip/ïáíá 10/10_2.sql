use ddblab0
go

SET SHOWPLAN_XML ON;  
GO  
SET SHOWPLAN_XML OFF;  
GO  


-- ������ ��� �������� ��������
/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO
*/

SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO

-- �������� ���������������� � ������������������ ������� ��� ���� ������ � �������� ��� �� ������

create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(shipcountry, orderdate, customerID)
GO
SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970910' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO

drop index cust_clust on customers1
drop index ord_clust on orders1

/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970910' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(shipcountry, orderdate, customerID)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF

drop index cust_clust on customers1
drop index ord_clust on orders1
*/
--------------------------------
SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO


create nonclustered index cust_nonclust on customers1(country, customerID) include (CompanyName)
create nonclustered index ord_nonclust on orders1(shipcountry, orderdate, customerID) include (ShipName, EmployeeID)

GO
SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO

drop index cust_nonclust on customers1
drop index ord_nonclust on orders1

/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

create nonclustered index cust_nonclust on customers1(country, customerID) include (CompanyName)
create nonclustered index ord_nonclust on orders1(shipcountry, orderdate, customerID) include (ShipName, EmployeeID)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF

drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
*/
---------------------

SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO


create nonclustered index cust_nonclust on customers1(country, customerID) include (CompanyName)
create nonclustered index ord_nonclust on orders1(shipcountry, orderdate, customerID) include (ShipName, EmployeeID)
create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(shipcountry, orderdate, customerID)

GO
SET SHOWPLAN_ALL ON
GO
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
GO
SET SHOWPLAN_ALL OFF
GO

drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index cust_clust on customers1
drop index ord_clust on orders1



/*
SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF
GO

create clustered index cust_clust on customers1(country, customerID)
create clustered index ord_clust on orders1(shipcountry, orderdate, customerID)
create nonclustered index cust_nonclust on customers1(country, customerID) include (CompanyName)
create nonclustered index ord_nonclust on orders1(shipcountry, orderdate, customerID) include (ShipName, EmployeeID)

SET STATISTICS IO ON
SET STATISTICS TIME ON
select cust.CompanyName, cust.city, ord.ShipName, ord.EmployeeID
from customers1 as cust join orders1 as ord on cust.CustomerID = ord.CustomerID
where cust.country = 'USA'
	and ord.shipcountry = 'USA'
	and ord.OrderDate between '19970923' and '19990730'
SET STATISTICS IO OFF
SET STATISTICS TIME OFF

drop index cust_nonclust on customers1
drop index ord_nonclust on orders1
drop index cust_clust on customers1
drop index ord_clust on orders1
*/