use ddblab0
go

SELECT * INTO Customers1 FROM ddblab0..Customers
DECLARE @count INT
SELECT @count = 10
WHILE @count >= 0
  BEGIN
    INSERT INTO Customers1 SELECT * FROM ddblab0..Customers
    SELECT @count = @count - 1
  END

SELECT * INTO Orders1 FROM ddblab0..Orders
SELECT * INTO OrderDetails1 FROM ddblab0.."Order Details"

SELECT * INTO Products1 FROM ddblab0..Products
SELECT @count = 10
WHILE @count >= 0
  BEGIN
    INSERT INTO Products1 (ProductName,SupplierID,CategoryID,QuantityPerUnit,
                                          UnitPrice,UnitsInStock,UnitsOnOrder,
                                                       ReorderLevel,Discontinued)
    SELECT ProductName,SupplierID,CategoryID,
             QuantityPerUnit,UnitPrice,UnitsInStock,
                UnitsOnOrder,ReorderLevel,Discontinued 
    FROM ddblab0..Products
    SELECT @count = @count - 1
  END

