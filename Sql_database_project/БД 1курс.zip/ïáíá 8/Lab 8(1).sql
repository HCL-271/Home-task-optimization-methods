

BEGIN TRANSACTION

	declare @d1 datetime;
	declare @diff int;
	declare @curr_tracefilename varchar(500);
	declare @base_tracefilename varchar(500);
	declare @indx int ;

	select @curr_tracefilename = path from sys.traces where is_default = 1 ;
	set @curr_tracefilename = reverse(@curr_tracefilename)
	select @indx = PATINDEX('%\%', @curr_tracefilename)
	set @curr_tracefilename = reverse(@curr_tracefilename)
	set @base_tracefilename = LEFT(@curr_tracefilename,len(@curr_tracefilename) - @indx) + '\log.trc';

	select distinct a.ObjectName
	from ::fn_trace_gettable( @base_tracefilename, default) a inner join ::fn_trace_gettable( @base_tracefilename, default) b on a.ObjectName = b.ObjectName
	where b.EventClass in (46,47,164) and b.EventSubclass = 0 and
	b.DatabaseID <> 2 and
	b.ObjectType = 8277 and
	b.LoginName = 'sa'
	
	ROLLBACK
	GO
	-- SELECT * FROM sys.traces
	--select path from sys.traces where is_default = 1 ;


	/*
BEGIN TRANSACTION

	declare @d1 datetime;
	declare @diff int;
	declare @curr_tracefilename varchar(500);
	declare @base_tracefilename varchar(500);
	declare @indx int ;

	select @curr_tracefilename = path from sys.traces where is_default = 1 ;
	set @curr_tracefilename = reverse(@curr_tracefilename)
	select @indx = PATINDEX('%\%', @curr_tracefilename)
	set @curr_tracefilename = reverse(@curr_tracefilename)
	set @base_tracefilename = LEFT(@curr_tracefilename,len(@curr_tracefilename) - @indx) + '\log.trc';

	select   distinct a.ObjectName
	from ::fn_trace_gettable( @base_tracefilename, default) a inner join ::fn_trace_gettable( @base_tracefilename, default) b on a.ObjectName = b.ObjectName
	--where b.EventClass in (46,47,164) and b.EventSubclass = 0 

	SELECT * FROM sys.fn_trace_gettable( @base_tracefilename, default)

	select * from sys.all_parameters*/