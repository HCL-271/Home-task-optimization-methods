mpicc 2_Temp.c -lm
echo p, N, T, dt, time
for n in 50
	do
	for p in 4
		do 
		mpiexec -np $p ./a.out $n
	done
done
