mpicc 2_Temp.c -lm

qsub boot.sh 


