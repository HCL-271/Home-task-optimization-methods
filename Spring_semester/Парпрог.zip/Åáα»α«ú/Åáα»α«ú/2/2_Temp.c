#include<stdio.h>
#include<stdlib.h>
#include<mpi.h> 
#include<time.h>
/*#include<cstdlib>*/

#include<math.h>



long double right_answer(long double x, long double T, long double k) {
	long double sum = 0;
	long double pi = 3.14159265358979323846;
	int i = 0;
	for ( i = 0; i < 100; i++) {
		sum += exp(-k * pi *pi * (2 * i + 1) * (2 * i + 1) * T) / (2 * i + 1) * sin(pi * (2 * i + 1) * x);
	}
	return 4.0 * 1 / pi * sum;
}	
	
	
int print_mas(const long double* mas, int N, long double T, long double k) {
printf("N = %d\n", N);
	int num_of_print = 10;
	int delta_h = N / num_of_print;
/*	printf("%d\t%.5f\t%.5f\n", 0, 0.0, 0.0);*/
	int i = 1;
	while (i <= N + 1) {
		long double xx = (1.0 * (i - 1)) / (1.0 * N);
		printf("%d\t%.5Lf\t%.5Lf\n", i - 1, mas[i], right_answer(xx, T, k));
		i += delta_h;
	}
printf("i = %d", i);
/*	printf("%d\t%.5f\t%.5f\n", N, 0.0, 0.0);	*/
	return 1;
}

int print_full_mas(const long double* mas, int N, int myrank) {
	printf("\n\n\n_____________________________________________\nproc\t%d\n", myrank);
	int i = 0;
	for ( i = 1; i <= N; i++) {
		printf("%.3Lf\n", mas[i]); 
	}
	printf("\n_____________________________________________\nend\t%d\n\n", myrank);
	return 0;
}

/*	mas - массив распределения температуры стержня
 *	N   - размер ВАЖНОЙ части стержня
 *	Есть ДВА важных факта
 * 	1	Сам массив содержит также БОКОВЫЕ элементы
 *		Например массив [1, 3, 2, 4, 0]. 
 *		Размер стержня 3
 *		'1' и '0' - боковые элементы, их не считаем
 *	2	Массив удвоенный. 
 */
int temp(long double* mas, int N, long double k, long double h, long double dt) {
	long double prev_val = mas[0];
	int i = 0;
/*printf("N = %d, k = %.3Lf h = %.10Lf dt = %.10Lf\n", N, k, h, dt);*/ 
	for ( i = 1; i <= N; i++) {
		long double yyy = mas[i];
/*printf("%.10Lf %.10Lf %.10Lf ", prev_val, mas[i], mas[i + 1]);*/
		mas[i] = k * dt * (prev_val - 2.0 * mas[i] + mas[i + 1]) / (h * h) + mas[i];
		prev_val = yyy;
/*printf("%.10Lf \n",  mas[i]);*/
	}
	return 1;
}

	
int main(int argc, char* argv[]){
	long double mail_double[0];/*через нее я буду перекидывать сообщения*/
	int mail_int; /*аналогично*/
	int myrank, size;
	MPI_Status Status; 

	MPI_Init(&argc, &argv);

/*  Каждому процессу присваивается уникальный номер */
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

/*  переменной size присваивается число, равное кол-ву процессов */
	MPI_Comm_size(MPI_COMM_WORLD, &size);


/*параметры уравнения	*/
	int N = atoi(argv[1]);
	long double h = 1.0 / (1.0 *  N);		/*расстояние между точками на стержне*/
	N++;
	long double k = 1.;			/*константа уравнения*/
	long double dt =/* 0.0000000002;// */ 0.000001; 	/*время одной итерации обновления данных*/
	long double T = /* 0.000001;/*/0.1;			/*время нагревания*/
	unsigned long long int num_of_iteration = (int) (T / dt); /*число итераций нагревания*/
	int delta_N = N / size; 
	int delta_N_proc;
	int i = 0; int j = 0; /*индексы на цикл*/	
	double begin;
	if (myrank == 0) {begin = MPI_Wtime(); }
	if (dt > 0.5 * h * h / k) {
		printf("\nERROR change N or dt\n\n"); 
		MPI_Finalize();
		return 0;
	}
	

	long double mas_proc[N / size + 10];
	if (myrank == 0) {
		mas[0] = 0.0; mas[1] = 0.0; mas[N] = 0.0; mas[N + 1] = 0.0;
		for ( i = 2; i < N; i++) {
			mas[i] = 1.0;
		}
		
		int remainder = N % size;
		int current = 1; int i = 1;
		
		delta_N_proc = delta_N;
		if (remainder > 0) {remainder--; delta_N_proc++;}
		int lll = delta_N_proc;
		for ( j = 0; j <= (delta_N_proc + 1); j++) {
			mas_proc[j] = mas[j];
		}
		current += delta_N_proc;
		while (i < size) {
			delta_N_proc = delta_N;
			if (remainder > 0) {remainder--; delta_N_proc++;}
			MPI_Send(&delta_N_proc, 1, MPI_INT, i, 1, MPI_COMM_WORLD);
			MPI_Send(&mas[current - 1], delta_N_proc + 2, MPI_LONG_DOUBLE, i, 1, MPI_COMM_WORLD);
			current += delta_N_proc;
			i++; 
		}
		delta_N_proc = lll;
	} else {
		MPI_Recv(&delta_N_proc, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &Status);
		MPI_Recv(mas_proc, delta_N_proc + 2, MPI_LONG_DOUBLE, 0, 1, MPI_COMM_WORLD, &Status);
	}

	for ( i = 0; i < num_of_iteration; i++) {
		temp(mas_proc, delta_N_proc, k, h, dt);
		int next = myrank + 1;
		if (myrank == size - 1) {
			mas_proc[delta_N_proc] = 0.0;
			next = MPI_PROC_NULL;
		}
		int previous = myrank - 1;
		if (myrank == 0) {
			mas_proc[1] = 0.0; 	
			previous = MPI_PROC_NULL;
		}
	
		if (myrank % 2 == 0) {
			MPI_Send( &mas_proc[1], 1, MPI_LONG_DOUBLE, previous, 1, MPI_COMM_WORLD);
			MPI_Send( &mas_proc[delta_N_proc + 0], 1, MPI_LONG_DOUBLE, next, 1, MPI_COMM_WORLD);
			MPI_Recv( &mas_proc[0], 1, MPI_LONG_DOUBLE, previous, 1, MPI_COMM_WORLD, &Status);
			MPI_Recv( &mas_proc[delta_N_proc + 1], 1, MPI_LONG_DOUBLE, next, 1, MPI_COMM_WORLD, &Status);  
		}
   		if (myrank % 2 == 1) {
			MPI_Recv( &mas_proc[delta_N_proc + 1], 1, MPI_LONG_DOUBLE, next, 1, MPI_COMM_WORLD, &Status);
			MPI_Recv( &mas_proc[0], 1, MPI_LONG_DOUBLE, previous, 1, MPI_COMM_WORLD, &Status);
			MPI_Send( &mas_proc[delta_N_proc], 1, MPI_LONG_DOUBLE, next, 1, MPI_COMM_WORLD); 
			MPI_Send( &mas_proc[1], 1, MPI_LONG_DOUBLE, previous, 1, MPI_COMM_WORLD);
		}
	}
	
	if (myrank == 0) {
		int current = 1;
		for ( j = 1; j <= delta_N_proc; j++) {
			mas[j] = mas_proc[j];
		}
		current += delta_N_proc;
		for ( i = 1; i < size; i++) {
			int delta_N_proc = 0;
			MPI_Recv(&delta_N_proc, 1, MPI_INT, i, 1, MPI_COMM_WORLD, &Status);
			MPI_Recv(&mas[current], delta_N_proc, MPI_LONG_DOUBLE, i, 1, MPI_COMM_WORLD, &Status);
			current += delta_N_proc;
		}

		double time = MPI_Wtime() - begin;
		printf("%d %d %.10Lf %.10Lf\t %.10lf\n", size, N - 1, T, dt, time);
		print_mas(mas, N - 1, T, k);
	} else {
		MPI_Send(&delta_N_proc, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
		MPI_Send(&mas_proc[1], delta_N_proc, MPI_LONG_DOUBLE, 0, 1, MPI_COMM_WORLD);
	}
	
    
	MPI_Finalize();
	return 0;
}
/*ssh -p 52960 s77819@remote.vdi.mipt.ru
 *
 * sudo apt install mpich
 * module add mpi/openmpi-x86_64
 * mpicc 1.c
 * mpiexec -np 2 ./a.out
 *
 * */




