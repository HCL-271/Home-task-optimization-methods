

#!/bin/bash 
#PBS -l walltime=00:01:00,nodes=3:ppn=4
#PBS -N xxxxx50000
#PBS -q batch 
cd $PBS_O_WORKDIR

echo p, N, T, dt, time
for n in 500
        do
        for p in 2 
                do
                mpirun -hostfile $PBS_NODEFILE -np $p ./a.out $n
        done
done
~                                                                                                    
~       
