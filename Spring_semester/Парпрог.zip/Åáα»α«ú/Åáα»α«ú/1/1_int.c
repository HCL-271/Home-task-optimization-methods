#include<stdio.h>
#include<stdlib.h>
#include<mpi.h> // заголовочный файл mpi
#include<time.h>

double func(double x) {
//	printf("%.2f\n",x); 
	return 4 / (1 + x * x);
}

//double Integr(double a; double b; int N) {
	


int main(int argc, char* argv[]){
	
	int j; //переменная цикла
	double SS[1];//через нее я буду перекидывать сообщения
	int array[10];//аналогично
	int myrank, size;
	MPI_Status Status; //тип данных mpi


	/* MPI программа начинается с MPI_Init; все остальные N  процессов начинают работу после этого */
	MPI_Init(&argc, &argv);

	/* каждому процессу присваивается уникальный номер */
        MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

	/* переменной size присваивается число, равное кол-ву процессов */
	MPI_Comm_size(MPI_COMM_WORLD, &size);


	int p = size;		//количество процессов
        int N = atoi(argv[1]);   //число разбиений
        double a = 0; 		//начало интегрирования
        double b = 1; 		//конец интегрирования
        double delta_x = (b - a) / N; //шаг интегрирования
        int delta_p = N / p; //количество разбиений на одном мини отрезка.
	
	double S = 0; double S1 = 1;
	double a0 = a + myrank * delta_x * delta_p; 

// нахожу стпень N = 10^NN
	int NN = 0; int NNN = N;  while (NNN > 1) {NNN /= 10; NN++;}
	
	double  start, end, start1, end1;
	start = MPI_Wtime();

	if (myrank == p - 1) { delta_p += N % p; } //в случае, еси N%p != 0, последний отрезок больше.
	for (j = 0; j < delta_p; j++) {
		S += func(a0 + delta_x * j);
	}
//	printf("a0 = %.2f,  b0 = %.2f, S = %.2f\n", a0, a0 + delta_x * delta_p, S);
	S *= delta_x;
	if (myrank != 0) {
		SS[0] = S;
		MPI_Send(&SS[0], 1, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
	}

	if (myrank == 0) {
	//	printf("\n\nИнтеграл функции 4/(1 + x^2) от %.1f до %.1f\nN = %d, p = %d\ndelta_x = %.5f\ndelta_p = %d\n\n\n", a, b, N, p, delta_x, delta_p);
	//	printf("S0 = %.5f\n", S);

		for (j = 1; j < p; j++) { 
			MPI_Recv(SS, 1, MPI_DOUBLE,/* j,*/ MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &Status);
			S += SS[0];
	//		printf("S%d = %.5f\n", Status.MPI_SOURCE,/* j,*/  SS[0]);

		} 
		end = MPI_Wtime();
		start1 = MPI_Wtime();
		for (j = 0; j < N; j++) {
               		S1 += func(delta_x * j);
        	}
		end1 = MPI_Wtime();
		double ans = (double)((double)(end1 - start1)/((double)(end - start)));
		printf("%d\t%d\t%.10f\t%f\n", p, NN, S, ans);
	}
	
	
	MPI_Finalize();
	return 0;
}
