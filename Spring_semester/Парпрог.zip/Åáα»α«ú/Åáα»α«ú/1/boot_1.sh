
for p in 1 2 3 4 5 6 7 8
        do
        for n in 1 10 100 1000 10000 1000000 10000000 100000000
                do
                mpiexec -np $p ./a.out $n
        done
        echo 
done                                                                           
