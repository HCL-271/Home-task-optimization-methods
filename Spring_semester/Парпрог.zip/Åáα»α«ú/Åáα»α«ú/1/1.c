#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
/*#include<time.h>*/

double f(double x) {
	return 4 / (1 + x * x);
}

int main(int argc, char* argv[]) {
	int i;
	int array[10];
	int myrank, size;
	MPI_Status Status;
	
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	
	int N = atoi(argv[1]);
	int p = size;
	double delta_x = (double)(1) / (double)(N);
	int part = N / p;
	if (myrank == p - 1) {
		part += N % p;
	}
	double Sums[1];
	
	int log10N = 0;
	int powN = N;
	while (powN > 1) {
		powN /= 10;
		log10N += 1;
	} 
    
    double a = (double)(myrank) * (double)(part) / (double)(N);
    //double b =
    double start, fin, start0, fin0;
    
    
    double S0 = 0;
	start0 = MPI_Wtime();
	
	for (i = 0; i < N; i++) {
		S0 += (f(i * delta_x) + f((i+1) * delta_x))/2;
	}
	S0 *= delta_x;
	
	fin0 = MPI_Wtime();
/*	printf("%.10f\n", S0);*/
	
	
	double S = 0;
	start = MPI_Wtime();
	
	for (int j = 0; j < part; j++) {
		S += (f(a + j * delta_x) + f(a + (j+1) * delta_x))/2;
	}
/*	printf("%d\t%.10f\n", myrank, S * delta_x);*/
	if (myrank != 0) {
		Sums[0] = S;
		MPI_Send(&Sums[0], 1, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);
	}
	if (myrank == 0) {
		for (i = 1; i < p; i++) {
			MPI_Receive(Sums, 1, MPI_DOUBLE, MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &Status/*MPI_STATUS_IGNORE??*/);
			S += Sums[0];
		}
		S *= delta_x;
	}
	
	fin = MPI_Wtime();
	
	
	double Accel = ((double)(fin0 - start0)) / ((double)(fin - start));
	printf("%d\t%d\t%.10f\t%f\n", log10N, p, S, ans); /* stepen' N*/
	
    MPI_Finalize();
	return 0;
}
