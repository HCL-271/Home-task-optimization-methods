#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>          /*   заголовочный файл pthread*/
#include<semaphore.h>
#include<math.h>
#include<time.h>

sem_t sem;
const int N = 1000000;
const double pi = 3.14159265;
int p = 10;
int inside_counter = 0;

/* Функция работы нити (область жизни нити)*/
void* start_func(void* param){
/*printf("\tSTART_FUNC\n");*/

        int local_rand;
        local_rand = *(int*) param;
        int j = 0;

        int x_k, y_k, z_k;
        int N_local = N / p;
        int S = 0;
        for (j = 0; j < N_local; j++) {
                double x = pi *  (rand_r(&local_rand) % 10000) / 10000;
                double y = 1.0 * (rand_r(&local_rand) % 10000) / 10000;
                double z = pi *  (rand_r(&local_rand) % 10000) / 10000;
                S += ((z <= x * y && x <= pi && y <= sin(x)) ? 1 : 0);
        }

        sem_wait(&sem);
        inside_counter += S;
        sem_post(&sem);
/*      sem_getvalue(&sem, &val);*/
/*printf("\tEND_FUNC\n");*/
        pthread_exit(NULL);
}






int main(int argc, char *argv[]) {

        sem_init(&sem, 0, 1);
        int param;
        int rc;
        void *arg;

        p = atoi(argv[1]);
        pthread_t *pthr = malloc(p * sizeof(int));

        struct timespec begin, end;
        double elapsed;
        clock_gettime(CLOCK_REALTIME, &begin);

        int* rand = (int*)malloc(p * sizeof(int));
        int i = 0;
        for (i = 0; i < p; i++) {
/*printf("i = %d\n", i); */
                rand[i] = i;
                rc = pthread_create(&pthr[i], NULL, start_func, (void*)&rand[i]);
                if (rc) printf("ERROR; return code from pthread_create() is %d \n", rc);
        }
        for (i = 0; i < p; i++) {
                rc = pthread_join(pthr[i], &arg);
                if (rc) printf("ERROR; return code from pthread_join() is %d \n", rc);
        }
        clock_gettime(CLOCK_REALTIME, &end);
        elapsed = end.tv_sec - begin.tv_sec;
        elapsed += (end.tv_nsec - begin.tv_nsec) / 1000000000.0;

        double result = (1.0 * inside_counter) / (1.0 * N) * pi * pi * 1.0;
        printf("%d\t%.5f\t\t%.5f\n", p, result, elapsed);
		sem_destroy(&sem);
//return 0;

}



