#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>          /*   заголовочный файл pthread*/
#include<semaphore.h>
#include<math.h>
#include<time.h>

const int PRINT = 1;
const double T = 4;
const double c = 1;
const double h = 0.1;
const double dt = 0.05;
const double max_X = 10;
const int print_dots = 100;
double * mas_email;
double * full_mas;
int count = 0; int count1 = 0; int count2 = 0; int count3 = 0;

sem_t sem_send, sem_get, sem_new_iter;

int NUM_THREADS;

double ggg(double x) {
        if ((0 <= x) && (x <= 2)) {
                return x * (2 - x);
        }
        return 0;
}


int print_full_mas(const double* mas, int N, int myrank) {
        printf("\n\n\n_____________________________________________\nproc\t%d\n", myrank);
        int i = 0;
        for ( i = 1; i <= N; i++) {
                printf("%.3f\n", mas[i]);
        }
        printf("\n_____________________________________________\nend\t%d\n\n", myrank);
        return 0;
}



int temp(double* mas, int N) {
        double prev_val = mas[0];
        int i = 0;
        for ( i = 1; i <= N; i++) {
                double yyy = mas[i];
                mas[i] = -c * dt * (mas[i] - prev_val) / h + mas[i];
                prev_val = yyy;
        }
        return 1;
}


/* Функция работы нити (область жизни нити)*/
void* start_func(void* param){
        int void_to_int = sizeof(int)/sizeof(void);
        int x_0   = ((int*)param)[0];
        int N_num = ((int*)param)[1] + 1;
        int rank  = ((int*)param)[2];
//printf("\t\t\tcurrent = %d, N_num1 = %d, i = %d\n", x_0, N_num, rank);
/* массив идет с первого элемента. Нулевой элемент - элемент соседа */
        double * mas = (double*)malloc((N_num + 2) * sizeof(double));
        int i = 0;

        sem_wait(&sem_send);
        for (i = 0; i < N_num; i++) {
                mas[i] = full_mas[i + x_0 - 1];
        }
        sem_post(&sem_send);


        int iter = 0;
        int N_iter = T / dt;

/* синхронизация происходит после прохождения каждого из этапов: */
/*     temp -> send -> get  */
        for (iter = 0; iter < N_iter  - 2; iter++) {
                temp(mas, N_num);

                sem_wait(&sem_send);
                count1++;
                mas_email[rank + 1] = mas[N_num - 1];
                if (count1 == NUM_THREADS) {
                        sem_post(&sem_get);
                        count1 = 0;
                } else {
                         sem_post(&sem_send);
                }

                sem_wait(&sem_get);
                count2++;
                mas[0] = mas_email[rank];
                if (count2 == NUM_THREADS) {
                        sem_post(&sem_new_iter);
                        count2 = 0;
                } else {
                        sem_post(&sem_get);
                }

                sem_wait(&sem_new_iter);
                count3++;
                if (count3 == NUM_THREADS) {
                        sem_post(&sem_send);
                        count3 = 0;
                } else {
                        sem_post(&sem_new_iter);
                }

        }

        sem_wait(&sem_send);
        for (i = 1; i < N_num; i++) {
                full_mas[x_0 + i]  = mas[i];
        }
        sem_post(&sem_send);

        free(mas); mas = NULL;
        pthread_exit(NULL);
        return NULL;
}


int main(int argc, char *argv[]) {

        int param;
        int rc;
        void *arg;

        NUM_THREADS = atoi(argv[1]);
        pthread_t *pthr = malloc(NUM_THREADS * sizeof(int));

        struct timespec begin, end;
        double elapsed;
        clock_gettime(CLOCK_REALTIME, &begin);

        int i = 0;
        sem_init(&sem_new_iter, 0, 0);
        sem_init(&sem_send, 0, 1);
        sem_init(&sem_get, 0, 0);

        int *starter = (int*)malloc(3 * sizeof(int) * (NUM_THREADS + 3));
        int N_all = (int) max_X / h ;
        int N_num = N_all / NUM_THREADS;
        int remainder = N_all % NUM_THREADS;
        int current = 1;


/* массив начинается с нулевого элемента. но 0й элемент обрабатывать не будут */
        full_mas = (double*)malloc((N_all + 3) * sizeof(double));
/*этот массив для обмена крайними точками между нитей*/
        mas_email = (double*)malloc((NUM_THREADS + 3) * sizeof(double));
        double x = 0.0; i = 0;
        while (x <= max_X) {
                full_mas[i] = ggg(x);
                x += h; i ++;
        }

        for (i = 0; i < NUM_THREADS; i++) {
                int N_num1 = N_num;
                if (remainder != 0) {
                        N_num1 ++;
                        remainder --;
                }
                starter[3 * i + 0] = current;
                starter[3 * i + 1] = N_num1;
                starter[3 * i + 2] = i;
                rc = pthread_create(&pthr[i], NULL, start_func, (void*)&starter[3 * i]);
                if (rc) printf("ERROR; return code from pthread_create() is %d \n", rc);
                current += N_num1;
        }
        for (i = 0; i < NUM_THREADS; i++) {
                rc = pthread_join(pthr[i], &arg);
                if (rc) printf("ERROR; return code from pthread_join() is %d \n", rc);
        }

        if (PRINT) {
                double print_delta_x = max_X / (1.0 * print_dots);
                int print_delta_n = N_all / print_dots;
                printf("T = %.2f\tdt = %.2f\th = %.5f\n", T, dt, h);
                printf("x\tprog\tright\n");
                for (i = 0;  i <= print_dots; i++) {
                        printf("%.1f\t%.6f\t%.6f\n", i *( 1.0 * max_X) / (1.0 * print_dots), full_mas[i * print_delta_n], ggg( i * print_delta_n * h  - c * T));
                }
        }
        clock_gettime(CLOCK_REALTIME, &end);
        elapsed = end.tv_sec - begin.tv_sec;
        elapsed += (end.tv_nsec - begin.tv_nsec) / 1000000000.0;

        printf("%d\t%.5f\n", NUM_THREADS, elapsed);
        sem_destroy(&sem_new_iter);
        sem_destroy(&sem_send);
        sem_destroy(&sem_get);
}





